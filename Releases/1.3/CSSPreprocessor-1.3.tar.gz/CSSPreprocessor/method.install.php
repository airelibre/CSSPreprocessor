<?php
if (!isset($gCms)) exit;

$this->AddEventHandler('Core', 'SmartyPreCompile', false);




?>
