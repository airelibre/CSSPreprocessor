<?php
$lang['cancel'] = 'Annuleer';
$lang['generate_sourcemap'] = 'Bronmap';
$lang['options'] = 'Opties';
$lang['preferences'] = 'Instellingen';
$lang['submit'] = 'Versturen';
$lang['ga'] = 'GA1.2.767965020.1400612364';
?>