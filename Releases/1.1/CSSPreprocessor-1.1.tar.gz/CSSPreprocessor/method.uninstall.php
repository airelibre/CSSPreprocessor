<?php
if (!isset($gCms)) exit;

$this->RemoveEventHandler('Core', 'SmartyPreCompile');




?>
