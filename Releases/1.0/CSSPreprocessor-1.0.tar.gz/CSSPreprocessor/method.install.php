<?php
if (!isset($gCms)) exit;

$this->AddEventHandler('Core', 'SmartyPostCompile', false);




?>
