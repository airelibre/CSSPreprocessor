<?php
$lang['cancel'] = 'Avbryt';
$lang['css_preprocessor'] = 'CSS Preprocessor';
$lang['choose_preprocessor'] = 'Velg den preprosessoren du vil benytte';
$lang['friendlyname'] = 'CSS Preprocessor';
$lang['generate_sourcemap'] = 'kildekart';
$lang['generate_sourcemap_label'] = 'Generer kildekart';
$lang['minify'] = 'Minimer';
$lang['note'] = 'Merknad:';
$lang['options'] = 'Valg';
$lang['preferences'] = 'Preferanser';
$lang['preferences_set'] = 'Preferansene ble lagret<br>Vennligst tøm ditt nettsteds mellomlager for å re-prosessere CSS';
$lang['submit'] = 'Lagre';
?>